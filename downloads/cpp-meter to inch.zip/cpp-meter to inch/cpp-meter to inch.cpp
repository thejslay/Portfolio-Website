#include <iostream>

using namespace std;

int main() {
	//convert meters to inches
	// 1 meter == 100 centimeters
	// 1 centimeter = .3937 inches

	float inch;
	float meter;

	// 100 cm in inches is 39.37" 
	// 1m = 39.37"

	cout << "\nEnter length in meters: ";
	cin >> meter;

	inch = meter * 39.37;
	cout << "\nLength in inches is: " << inch << endl;

	
	return 0;
}