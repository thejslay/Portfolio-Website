#include <iostream>
#include <iomanip>

using namespace std;

int main() {

	// calculate volume of sphere
	// formula is v=(4.0/3.0) * pi *r*r*r
	//pi = 3.14159
	//r = radius

	float volume;
	float radius;
	const float pi = 3.14;

	cout << "\nEnter the radius of the sphere: ";
	cin >> radius;

	volume = (4.0 / 3.0) * 3.14 * radius * radius * radius;
	// No clue if you want specific decimal places so I took a chance :)
	cout << fixed << setprecision(2);
	cout << "\nThe volume of the sphere is: " << volume << endl;

	return 0;
}